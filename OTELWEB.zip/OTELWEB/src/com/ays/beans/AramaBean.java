package com.ays.beans;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.ays.entity.Musteri;
import com.ays.entity.Oda;

@ManagedBean(name="arama")
@RequestScoped
public class AramaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	Connection connection;
	String odaFiyat;
	String odaDetay;
    String musteriAd;
    String musteriSoyad;
	String musteriTelefon;
    String musteriMail;
    String musteriPassword;
    String userName;
    String gender;
    String address;
    Integer musteriId;

	List<Oda> listeOda = new ArrayList<Oda>();
	List<MusteriBean> listeMusteri = new ArrayList<MusteriBean>();

	public String getOdaFiyat() {
		return odaFiyat;
	}

	public void setOdaFiyat(String odaFiyat) {
		this.odaFiyat = odaFiyat;
	}

	public String getOdaDetay() {
		return odaDetay;
	}

	public void setOdaDetay(String odaDetay) {
		this.odaDetay = odaDetay;
	}

	public List<Oda> getListeOda() {
		return listeOda;
	}

	public void setListeOda(List<Oda> listeOda) {
		this.listeOda = listeOda;
	}
	
	

	public String getMusteriAd() {
		return musteriAd;
	}

	public void setMusteriAd(String musteriAd) {
		this.musteriAd = musteriAd;
	}

	public String getMusteriSoyad() {
		return musteriSoyad;
	}

	public void setMusteriSoyad(String musteriSoyad) {
		this.musteriSoyad = musteriSoyad;
	}



	
	

	public List<MusteriBean> getListeMusteri() {
		return listeMusteri;
	}

	public void setListeMusteri(List<MusteriBean> listeMusteri) {
		this.listeMusteri = listeMusteri;
	}

	public String getMusteriTelefon() {
		return musteriTelefon;
	}

	public void setMusteriTelefon(String musteriTelefon) {
		this.musteriTelefon = musteriTelefon;
	}

	public String getMusteriMail() {
		return musteriMail;
	}

	public void setMusteriMail(String musteriMail) {
		this.musteriMail = musteriMail;
	}

	public String getMusteriPassword() {
		return musteriPassword;
	}

	public void setMusteriPassword(String musteriPassword) {
		this.musteriPassword = musteriPassword;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	


	public Integer getMusteriId() {
		return musteriId;
	}

	public void setMusteriId(Integer musteriId) {
		this.musteriId = musteriId;
	}

	// CONNECTION
	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/oteldb?useSSL=false&amp;serverTimezone=UTC", "root", "1234");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}
	
	//ODA ARA
	  public String odaAra(){
		 int result=0;
	        try{
	        	connection = getConnection();
	        	Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM tbl_oda WHERE oda_detay OR oda_fiyat");
	        
	             while(rs.next()) {
	                Oda o = new Oda();
	                if(odaFiyat.equals(rs.getString("ODA_FIYAT")) || odaDetay.equals(rs.getString("ODA_DETAY"))){
	                    o.setOdaFiyat(rs.getString("ODA_FIYAT"));
	                    o.setOdaDetay(rs.getString("ODA_DETAY"));
	                   
	                    listeOda.add(o);
	                }
	            }  
	        }
	        catch(Exception e)
	        {
	            System.err.println(e);
	        }
	        
	        return null;
	    }
	  
	  //MUSTER� ARA--->t�m hepsini almam gerekti ko�ullu dene!!!!
		public String musteriAra() {
			int result = 0;
			try {
				connection = getConnection();
				Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM tbl_musteri WHERE MUSTERI_AD OR MUSTERI_SOYAD OR ADDRESS OR CINSIYET OR MUSTERI_EMAIL OR PASSWORD OR MUSTERI_TELEFON OR USERNAME OR MUSTERI_ID");

				while (rs.next()) {
					MusteriBean mst = new MusteriBean();
					if (musteriAd.equals(rs.getString("MUSTERI_AD")) || 
				  musteriSoyad.equals(rs.getString("MUSTERI_SOYAD")) ||
			  musteriTelefon.equals(rs.getString("MUSTERI_TELEFON")) ||
				    musteriMail.equals(rs.getString("MUSTERI_EMAIL"))||
					 musteriPassword.equals(rs.getString("PASSWORD"))||
							userName.equals(rs.getString("USERNAME"))||
							  address.equals(rs.getString("ADDRESS"))||
								gender.equals(rs.getString("CINSIYET"))||
								musteriId.equals(rs.getInt("MUSTERI_ID"))) {
						mst.setMusteriAd(rs.getString("MUSTERI_AD"));
						mst.setMusteriSoyad(rs.getString("MUSTERI_SOYAD"));
						mst.setMusteriTelefon(rs.getString("MUSTERI_TELEFON"));
						mst.setMusteriMail(rs.getString("MUSTERI_EMAIL"));
						mst.setMusteriPassword(rs.getString("PASSWORD"));
						mst.setUserName(rs.getString("USERNAME"));
						mst.setAddress(rs.getString("ADDRESS"));
						mst.setGender(rs.getString("CINSIYET"));
						mst.setMusteriId(rs.getInt("MUSTERI_ID"));

						listeMusteri.add(mst);
					}
				}
			} catch (Exception e) {
				System.err.println(e);
			}

			return null;
		}
		
		

}
