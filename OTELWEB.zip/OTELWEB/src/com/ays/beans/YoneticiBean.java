package com.ays.beans;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import com.ays.entity.Personel;
import com.ays.util.DBUtil;

@ManagedBean(name = "yonetici")
@RequestScoped
public class YoneticiBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer yoneticiId;
	private String password ;
	private String userName ;
	private String yoneticiAd;
	private String yoneticiSoyad;
	ArrayList personelList;
	Personel personel;

	private Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

	Connection connection;

	public YoneticiBean() {
		// TODO Auto-generated constructor stub
	}

	// CONNECTION
	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/oteldb?useSSL=false&amp;serverTimezone=UTC", "root", "1234");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}

	public Integer getYoneticiId() {
		return yoneticiId;
	}

	public void setYoneticiId(Integer yoneticiId) {
		this.yoneticiId = yoneticiId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getYoneticiAd() {
		return yoneticiAd;
	}

	public void setYoneticiAd(String yoneticiAd) {
		this.yoneticiAd = yoneticiAd;
	}

	public String getYoneticiSoyad() {
		return yoneticiSoyad;
	}

	public void setYoneticiSoyad(String yoneticiSoyad) {
		this.yoneticiSoyad = yoneticiSoyad;
	}

	public ArrayList getPersonelList() {
		return personelList;
	}

	public void setPersonelList(ArrayList personelList) {
		this.personelList = personelList;
	}

	public Personel getPersonel() {
		return personel;
	}

	public void setPersonel(Personel personel) {
		this.personel = personel;
	}
	

	// Yonetici personelleri listelesin AYRINTILARIYLA
	public ArrayList personelList() {
		try {
			personelList = new ArrayList();
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select*from tbl_personel");
			while (rs.next()) {
				Personel personel = new Personel();
				personel.setPersonelId(rs.getInt("PERSONEL_ID"));
				personel.setPersonelAd(rs.getString("PERSONEL_AD"));
				personel.setPersonelSoyad(rs.getString("PERSONEL_SOYAD"));
				personel.setPassword(rs.getString("PASSWORD"));
				personel.setUserName(rs.getString("USERNAME"));
				personel.setPersonelMail(rs.getString("PERSONEL_EMAIL"));

				personelList.add(personel);
			}
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return personelList;
	}

//save delete update  personel s�n�f�ndan alcam.Yonetici personel dair her i�lemi yapacak
	// yoneticiler
	// ARZU Yenilmez,Sevda Turk,Aysun Yenilmez.���n�n yetkisi olcak

	
	//3 y�netici de giri� yapabiliyor
	
	public  String yoneticiLogin() {
		
	
		Connection con = null;
		PreparedStatement ps = null;

		try {
			con = DBUtil.getMySQLConnection();
			ps = con.prepareStatement(
					"Select username, password from tbl_yonetici where username = ? and password = ?");
			ps.setString(1, userName);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				
				return "yoneticiLogin2.xhtml?faces-redirect=true";
			}
		} catch (SQLException e) {
			System.out.println("Hata" + e.getMessage());

			
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		return "error.jsp?redirect=true";

	}
}
