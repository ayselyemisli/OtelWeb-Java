package com.ays.beans;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import javax.validation.constraints.NotNull;

import com.ays.entity.Musteri;
import com.ays.entity.Oda;
import com.ays.util.DBUtil;


@ManagedBean(name = "musteri")
@RequestScoped
public class MusteriBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private int musteriId;

	private String musteriAd;

	private String musteriSoyad;

	private String musteriTelefon;

	private String musteriMail;

	private String musteriPassword;

	private String userName;

	private String gender;

	private String address;

	ArrayList musteriList;

	
	RezarvasyonBean rezervasyonId, rezervasyonCikis, rezervasyonGiris;
	OdaBean odaId;

	private Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

	Connection connection;

	// BO� CONSTRUCTOR
	public MusteriBean() {

	}

	// PARAMETRELI CONSTRUCTOR
	public MusteriBean(String musteriAd, String musteriSoyad, String musteriTelefon, String musteriMail,
			String musteriPassword, String userName, String gender, String address) {

		this.musteriAd = musteriAd;
		this.musteriSoyad = musteriSoyad;
		this.musteriTelefon = musteriTelefon;
		this.musteriMail = musteriMail;
		this.musteriPassword = musteriPassword;
		this.userName = userName;
		this.gender = gender;
		this.address = address;
	}

	// CONNECTION
	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/oteldb?useSSL=false&amp;serverTimezone=UTC", "root", "1234");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}

	// GETTER-SETTER

	public int getMusteriId() {
		return musteriId;
	}

	public void setMusteriId(int musteriId) {
		this.musteriId = musteriId;
	}

	public String getMusteriAd() {
		return musteriAd;
	}

	public void setMusteriAd(String musteriAd) {
		this.musteriAd = musteriAd;
	}

	public String getMusteriSoyad() {
		return musteriSoyad;
	}

	public void setMusteriSoyad(String musteriSoyad) {
		this.musteriSoyad = musteriSoyad;
	}

	public String getMusteriTelefon() {
		return musteriTelefon;
	}

	public void setMusteriTelefon(String musteriTelefon) {
		this.musteriTelefon = musteriTelefon;
	}

	public String getMusteriMail() {
		return musteriMail;
	}

	public void setMusteriMail(String musteriMail) {
		this.musteriMail = musteriMail;
	}

	public String getMusteriPassword() {
		return musteriPassword;
	}

	public void setMusteriPassword(String musteriPassword) {
		this.musteriPassword = musteriPassword;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public ArrayList getMusteriList() {
		return musteriList;
	}

	public void setMusteriList(ArrayList musteriList) {
		this.musteriList = musteriList;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public RezarvasyonBean getRezervasyonId() {
		return rezervasyonId;
	}

	public void setRezervasyonId(RezarvasyonBean rezervasyonId) {
		this.rezervasyonId = rezervasyonId;
	}

	public RezarvasyonBean getRezervasyonCikis() {
		return rezervasyonCikis;
	}

	public void setRezervasyonCikis(RezarvasyonBean rezervasyonCikis) {
		this.rezervasyonCikis = rezervasyonCikis;
	}

	public RezarvasyonBean getRezervasyonGiris() {
		return rezervasyonGiris;
	}

	public void setRezervasyonGiris(RezarvasyonBean rezervasyonGiris) {
		this.rezervasyonGiris = rezervasyonGiris;
	}

	public OdaBean getOdaId() {
		return odaId;
	}

	public void setOdaId(OdaBean odaId) {
		this.odaId = odaId;
	}

	
	// MUSTERI LISTE TUM
	public ArrayList musteriList() {
		try {
			musteriList = new ArrayList();
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select*from tbl_musteri");

			while (rs.next()) {
				MusteriBean mst = new MusteriBean();
				mst.setMusteriId(musteriId);
				mst.setMusteriId(rs.getInt("MUSTERI_ID"));
				mst.setMusteriAd(rs.getString("MUSTERI_AD"));
				mst.setMusteriSoyad(rs.getString("MUSTERI_SOYAD"));
				mst.setMusteriTelefon(rs.getString("MUSTERI_TELEFON"));
				mst.setUserName(rs.getString("USERNAME"));
				mst.setMusteriMail(rs.getString("MUSTERI_EMAIL"));
				mst.setMusteriPassword(rs.getString("PASSWORD"));
				mst.setGender(rs.getString("CINSIYET"));
				mst.setAddress(rs.getString("ADDRESS"));

				System.out.println(rs.getString("PASSWORD"));
				musteriList.add(mst);

			}
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return musteriList;
	}

	// TBL_MUSTERI ===>KAYDET(save)
	public String save() {
		int result = 0;
		try {
			connection = getConnection();
			PreparedStatement psmt = connection.prepareStatement(
					"INSERT INTO tbl_musteri (MUSTERI_AD,MUSTERI_SOYAD,MUSTERI_TELEFON,USERNAME,MUSTERI_EMAIL,PASSWORD,CINSIYET,ADDRESS)VALUES(?,?,?,?,?,?,?,?)");

			psmt.setString(1, musteriAd);
			psmt.setString(2, musteriSoyad);
			psmt.setString(3, musteriTelefon);
			psmt.setString(4, userName);
			psmt.setString(5, musteriMail);
			psmt.setString(6, musteriPassword);
			psmt.setString(7, gender);
			psmt.setString(8, address);

			result = psmt.executeUpdate();

			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		if (result != 0)  //ilk otelGiris.xhtml denedim
			return "musteriLogin.xhtml?faces-redirect=true";
		else
			return "createMusteri.xhtml?faces-redirect=true";
	}

	// TBL_MUSTERI // EDIT-DUZENLE-g�ncellemek �zere kay�t getirme i�in

	public String edit(int musteriId) {
		MusteriBean must = null;
		System.out.println(musteriId);
		try {
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_musteri where MUSTERI_ID = " + (musteriId));
			rs.next();
			must = new MusteriBean();
			must.setMusteriId(rs.getInt("MUSTERI_ID"));
			must.setMusteriAd(rs.getString("MUSTERI_AD"));
			must.setMusteriSoyad(rs.getString("MUSTERI_SOYAD"));
			must.setMusteriTelefon(rs.getString("MUSTERI_TELEFON"));
			must.setUserName(rs.getString("USERNAME"));
			must.setMusteriMail(rs.getString("MUSTERI_EMAIL"));
			must.setMusteriPassword(rs.getString("PASSWORD"));
			must.setGender(rs.getString("CINSIYET"));
			must.setAddress(rs.getString("ADDRESS"));

			System.out.println(rs.getString("PASSWORD"));

			sessionMap.put("editMusteri", must);
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "/edit.xhtml?faces-redirect=true";
	}

	// Guncelleme(id) UPDATE
	public String update(MusteriBean must) {

		// MUSTERI_AD,MUSTERI_SOYAD,MUSTERI_TELEFON,USERNAME,MUSTERI_EMAIL,PASSWORD,CINSIYET,ADDRESS

		try {
			connection = getConnection();
			PreparedStatement psmt = connection.prepareStatement(
					"update tbl_musteri set  MUSTERI_AD=?,MUSTERI_SOYAD=?,MUSTERI_TELEFON=?,USERNAME=?,MUSTERI_EMAIL=?,PASSWORD=?,CINSIYET=?,ADDRESS=? where MUSTERI_ID=?");
			psmt.setInt(1, must.getMusteriId());
			psmt.setString(2, must.getMusteriAd());
			psmt.setString(3, must.getMusteriSoyad());
			psmt.setString(4, must.getMusteriTelefon());
			psmt.setString(5, must.getUserName());
			psmt.setString(6, must.getMusteriMail());
			psmt.setString(7, must.getMusteriPassword());
			psmt.setString(8, must.getGender());
			psmt.setString(9, must.getAddress());

			psmt.executeUpdate();
			connection.close();
		} catch (Exception e) {
			System.out.println();
		}
		return "/index.xhtml?faces-redirect=true";
	}

	// ID ye gore sil(delete)
	public void delete(int musteriId) {
		try {
			connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement("delete from tbl_musteri where MUSTERI_ID = " + musteriId);
			stmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// Cinsiyet se�im
	public String getGenderName(char gender) {
		if (gender == 'E') {
			return "Erkek";
		} else
			return "Kad�n";
	}

//	// Login !!!kontrol et //logindao class�m� sildiim
//	public String validateUsernamePassword() {
//		boolean valid = LoginDao.validate(userName, musteriPassword);
//		if (valid) {
//			HttpSession session = SessionUtils.getSession();
//			session.setAttribute("username", userName);
//			return "admin";
//		} else {
//			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
//					"Yanl�� Parola veya Kullan�c� ad�", "L�tfen do�ru kullanc� ad� veya parola ile giri� yap"));
//			return "login";
//		}
//	}

	// Musteri login
	public String musteriLogin() {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			con = DBUtil.getMySQLConnection();
			ps = con.prepareStatement(
					"Select username, password from tbl_musteri where username = ? and password = ?");
			ps.setString(1, userName);
			ps.setString(2, musteriPassword);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
			//	JOptionPane.showMessageDialog(null, "Giri� Ba�ar�l�"); //
				return "musteriRehber.xhtml?faces-redirect=true";
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage()+ "Hata");

		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		return "error.jsp?redirect=true";
	}

//bolumdeki i�lemler i�in yonetici giri� olu�tur 



}
