package com.ays.beans;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.ays.entity.EtkinlikRezervasyon;
import com.ays.entity.Musteri;
import com.ays.util.HibernateUtil;

@ManagedBean(name="etkinlik")
@RequestScoped
public class EtkinlikBean implements Serializable {
	
	private int etkinlikId;
	private String etkinlikAd;
	private String etkinlikYer;
	private String etkinlikSaat;
	private List<String> liste=new ArrayList<String>();
	private String dosya;
	ArrayList etkinlikList;
	Musteri musteri;
	private  String tarih;

	private Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

	Connection connection;
	
	public EtkinlikBean() {
		//liste i�in //Otomatik tamamlama da tamal�yor action ver Aysel!!!!
		liste.add("T�rkiye");
		liste.add("USA");
		liste.add("�sve�");
		
		
	}
	public EtkinlikBean( String etkinlikAd, String etkinlikYer, String etkinlikSaat,Musteri musteri) {
		
		this.musteri=musteri;
		this.etkinlikAd = etkinlikAd;
		this.etkinlikYer = etkinlikYer;
		this.etkinlikSaat = etkinlikSaat;
	}
	public int getEtkinlikId() {
		return etkinlikId;
	}
	public void setEtkinlikId(int etkinlikId) {
		this.etkinlikId = etkinlikId;
	}
	public String getEtkinlikAd() {
		return etkinlikAd;
	}
	public void setEtkinlikAd(String etkinlikAd) {
		this.etkinlikAd = etkinlikAd;
	}
	public String getEtkinlikYer() {
		return etkinlikYer;
	}
	public void setEtkinlikYer(String etkinlikYer) {
		this.etkinlikYer = etkinlikYer;
	}
	public String getEtkinlikSaat() {
		return etkinlikSaat;
	}
	public void setEtkinlikSaat(String etkinlikSaat) {
		this.etkinlikSaat = etkinlikSaat;
	}
	public ArrayList getEtkinlikList() {
		return etkinlikList;
	}
	public void setEtkinlikList(ArrayList etkinlikList) {
		this.etkinlikList = etkinlikList;
	}
	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}
	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}
	
	
	public Musteri getMusteri() {
		return musteri;
	}
	public void setMusteri(Musteri musteri) {
		this.musteri = musteri;
	}
	
	
	
	public List<String> getListe() {
		return liste;
	}
	public void setListe(List<String> liste) {
		this.liste = liste;
	}
	public String getDosya() {
		return dosya;
	}
	public void setDosya(String dosya) {
		this.dosya = dosya;
	}
	
	
	
	public String getTarih() {
		return tarih;
	}
	public void setTarih(String tarih) {
		this.tarih = tarih;
	}
	//CONNECTION
	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/oteldb?useSSL=false&amp;serverTimezone=UTC", "root", "1234");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}
	
	public ArrayList etkinlikList() {
		try {
			etkinlikList = new ArrayList();
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_etkinlik");
			while (rs.next()) {
				EtkinlikRezervasyon etk=new EtkinlikRezervasyon();
				etk.setEtkinlikAd(rs.getString("ETKINLIK_AD"));
				etk.setEtkinlikSaat(rs.getString("ETKINLIK_TARIH"));
				etk.setEtkinlikYer(rs.getString("ETKINLIK_YER"));
				etk.setEtkinlikId(rs.getInt("ETKINLIK_ID"));
			
				etkinlikList.add(etk);
				
				System.out.println("Liste" + etkinlikList);
			}
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return etkinlikList;
	}
	
	//liste otomatik tamamlama
	public List<String> oneri(String query){
		
		List<String> oneriList= new ArrayList<String>();
		
		if(query==null) {
			return oneriList;
		}
		
		for(String list1:liste) {
			if(list1.startsWith(query)) {
				oneriList.add(list1);
			}
		}
		return oneriList;
	}
	
	
	public void tarih() {
		Calendar cal =Calendar.getInstance();
		cal.getTime();
			
		}
		
	
	
	//JDBC
//Save 
public String save() {
	int result = 0;
	try {
		connection = getConnection();
		PreparedStatement psmt = connection.prepareStatement(
				"INSERT INTO tbl_etkinlik(ETKINLIK_AD,ETKINLIK_YER,ETKINLIK_TARIH)VALUES(?,?,?)");

		psmt.setString(1, etkinlikAd);
		psmt.setString(2, etkinlikSaat);
		psmt.setString(3, etkinlikYer);

		result = psmt.executeUpdate();

		connection.close();
	} catch (Exception e) {
		System.out.println(e);
	}
	if (result != 0)
		return "etkinlik.xhtml?faces-redirect=true";
	else
		return "personelislem2.xhtml?faces-redirect=true";
}

public String edit(int etkinlikId) {
	EtkinlikRezervasyon etkr = null;
	System.out.println(etkinlikId);
	try {
		connection = getConnection();
		Statement stmt = getConnection().createStatement();
		ResultSet rs = stmt.executeQuery("select * from tbl_etkinlik where ETKINLIK_ID = " + (etkinlikId));
		rs.next();
		etkr = new EtkinlikRezervasyon();
		etkr.setEtkinlikId(rs.getInt("ETKINLIK_ID"));
		etkr.setEtkinlikAd(rs.getString("ETKINLIK_AD"));
		etkr.setEtkinlikYer(rs.getString("ETKINLIK_YER"));
		etkr.setEtkinlikSaat(rs.getString("ETKINLIK_TARIH"));
		
		

		sessionMap.put("editEtkinlik", etkr);
		connection.close();
	} catch (Exception e) {
		System.out.println(e);
	}
	return "/editEtkinlik.xhtml?faces-redirect=true";
}


public void delete(int etkinlikId) {
	try {
		connection = getConnection();
		PreparedStatement stmt = connection
				.prepareStatement("delete from tbl_etkinlik where etkinlik_id = " + etkinlikId);
		stmt.executeUpdate();
	} catch (Exception e) {
		System.out.println(e);
	}
	
	
}

public String update(EtkinlikRezervasyon etkinlikRezervasyon) {
	
	try {
		connection = getConnection();
		PreparedStatement psmt = connection.prepareStatement(
				"update tbl_etkinlik set etkinlikAd=?,etkinlikYer=?,etkinlikSaat=? where etkinlikId=?");
		psmt.setString(1, etkinlikRezervasyon.getEtkinlikAd());
		psmt.setString(2, etkinlikRezervasyon.getEtkinlikSaat());
		psmt.setString(3, etkinlikRezervasyon.getEtkinlikYer());
		psmt.setInt(4, etkinlikRezervasyon.getEtkinlikId());
		psmt.executeUpdate();
		connection.close();
	} catch (Exception e) {
		System.out.println();
	}
	return "/editEtkinlik.xhtml?faces-redirect=true";
}

}

	
	
	
	
	
	
	


