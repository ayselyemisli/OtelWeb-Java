package com.ays.beans;

import java.io.Serializable;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;

import com.ays.entity.Musteri;
import com.ays.entity.Oda;
import com.ays.entity.Rezarvasyon;
import com.ays.util.HibernateUtil;

@ManagedBean(name = "rezervasyon")
@RequestScoped
public class RezarvasyonBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private int rezervasyonId;
	private Date rezervasyonGiris;
	private Date rezervasyonCikis;
	
	
	int musteriId;
    int odaId;
	MusteriBean musteriAd,musteriSoyad;
	


	ArrayList rezervasyonList;

	Connection connection;

	private Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

	public RezarvasyonBean() {
		// TODO Auto-generated constructor stub
	}

	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/oteldb?useSSL=false&amp;serverTimezone=UTC", "root", "1234");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}

	public int getRezervasyonId() {
		return rezervasyonId;
	}

	public void setRezervasyonId(int rezervasyonId) {
		this.rezervasyonId = rezervasyonId;
	}



	public Date getRezervasyonGiris() {
		return rezervasyonGiris;
	}

	public void setRezervasyonGiris(Date rezervasyonGiris) {
		this.rezervasyonGiris = rezervasyonGiris;
	}

	public Date getRezervasyonCikis() {
		return rezervasyonCikis;
	}

	public void setRezervasyonCikis(Date rezervasyonCikis) {
		this.rezervasyonCikis = rezervasyonCikis;
	}
	
	


	public int getMusteriId() {
		return musteriId;
	}

	public void setMusteriId(int musteriId) {
		this.musteriId = musteriId;
	}

	public MusteriBean getMusteriAd() {
		return musteriAd;
	}

	public void setMusteriAd(MusteriBean musteriAd) {
		this.musteriAd = musteriAd;
	}

	public MusteriBean getMusteriSoyad() {
		return musteriSoyad;
	}

	public void setMusteriSoyad(MusteriBean musteriSoyad) {
		this.musteriSoyad = musteriSoyad;
	}



	public int getOdaId() {
		return odaId;
	}

	public void setOdaId(int odaId) {
		this.odaId = odaId;
	}

	public ArrayList getRezervasyonList() {
		return rezervasyonList;
	}

	public void setRezervasyonList(ArrayList rezervasyonList) {
		this.rezervasyonList = rezervasyonList;
	}

	public void tarihSec(SelectEvent event) {
		// tek bir JavaServer Faces iste�inin i�lenmesi ve kar��l�k gelen yan�t�n
		// olu�turulmas�yla ilgili t�m istek ba��na durum bilgilerini i�erir.
		FacesContext facesContext = FacesContext.getCurrentInstance();
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		facesContext.addMessage(null,
				new FacesMessage(FacesMessage.SEVERITY_INFO, "Date Selected", format.format(event.getObject())));

	}



	public ArrayList rezervasyonList() {
		try {
			rezervasyonList = new ArrayList();
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery(
					"select r.giris,r.cikis,r.oda_id,r.REZERVASYON_ID,m.musteri_ad,m.musteri_id,m.musteri_soyad\r\n"
							+ "from tbl_rezervasyon r,tbl_musteri m\r\n" + "where r.musteri_id=m.musteri_id");
			
			while (rs.next()) {
				RezarvasyonBean rez = new RezarvasyonBean();
				MusteriBean musteri = new MusteriBean();
				OdaBean oda = new OdaBean();
				rez.setRezervasyonId(rezervasyonId);
				rez.setRezervasyonId(rs.getInt("REZERVASYON_ID"));
				rez.setRezervasyonCikis(rs.getDate("CIKIS"));
				rez.setRezervasyonGiris(rs.getDate("GIRIS"));
				musteri.setMusteriId(rs.getInt("MUSTERI_ID"));
				musteri.setMusteriAd(rs.getString("MUSTERI_AD"));
				musteri.setMusteriSoyad(rs.getString("MUSTERI_SOYAD"));
				oda.setOdaId(rs.getInt("ODA_ID"));

				rezervasyonList.add(rez);
				rezervasyonList.add(musteri);
				rezervasyonList.add(oda);

			}
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return rezervasyonList;
	}
	
	
	public String rezervasyonYap()  {

		int result = 0;
		try {
			
//			RezarvasyonBean rez =new RezarvasyonBean();
//			OdaBean oda = new OdaBean();
//			MusteriBean musteri = new MusteriBean();
//			connection = getConnection();
//			PreparedStatement psmt = connection
//					.prepareStatement("INSERT INTO  tbl_rezervasyon (REZERVASYON_ID,GIRIS,CIKIS,MUSTERI_ID,ODA_ID)VALUES(?,?,?,?,?)");
//		
//			
			
		//	"INSERT INTO  tbl_rezervasyon (CIKIS,GIRIS ) Select tbl_rezervasyon.giris,tbl_rezervasyon.cikis From tbl_musteri INNER JOIN tbl_rezervasyon ON tbl_rezervasyon.musteri_id=tbl_musteri.musteri_id"//
//		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
//		String dateOfBirth = sdf.format(rezervasyonGiris);
//		
//		SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
//		String dateOfBirth2 = sdf2.format(rezervasyonCikis);
//	 
				RezarvasyonBean rez =new RezarvasyonBean();
				OdaBean oda = new OdaBean();
				MusteriBean musteri = new MusteriBean();
				connection = getConnection();
				PreparedStatement psmt = connection
						.prepareStatement("INSERT INTO  tbl_rezervasyon (REZERVASYON_ID,CIKIS,GIRIS,MUSTERI_ID,ODA_ID)VALUES(?,?,?,?,?)");
				
			
				psmt.setInt(1, rezervasyonId);
				psmt.setDate(2, (java.sql.Date)rezervasyonCikis);
				psmt.setDate(3,(java.sql.Date)rezervasyonGiris);
				psmt.setInt(4, musteriId);
				psmt.setInt(5, odaId);
				
		result = psmt.executeUpdate();

		connection.close();
	} catch (Exception e) {
		System.out.println(e);
	}
		
		if (result != 0)
			return "otelGiris.xhtml?faces-redirect=true";
		else
			return "createMusteri.xhtml?faces-redirect=true";
	}

		
//		
//	
		
//		psmt.setInt(3, musteri.getMusteriId());
//		psmt.setInt(4, oda.getOdaId());
//		psmt.setString(5, musteri.getMusteriAd());
//		psmt.setString(6, musteri.getMusteriSoyad());

//		result = psmt.executeUpdate();
//
//		connection.close();
//	} catch (Exception e) {
//		System.out.println(e);
//	}
		
		
		
		
		
//		 String rezervasyonGiris = null;
//		 String rezervasyonCikis = null;
//		int result = 0;
//		try {
//					Session session = HibernateUtil.getSessionfactory().openSession();
//					session.beginTransaction();
//					Rezarvasyon rezer = new Rezarvasyon();
//					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
//					Date dateOfBirth = sdf.parse(rezervasyonGiris);
//					
//					SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
//					Date dateOfBirth2 = sdf2.parse(rezervasyonCikis);
//				
//
//					
//					rezer.setRezervasyonGiris(dateOfBirth);
//					rezer.setRezervasyonCikis(dateOfBirth2);
//					rezer.setMusteri(musteri);
//					rezer.setOda(oda);
//					
//
//					session.save(rezer);
//					session.getTransaction().commit();
//					session.clear();
//					session.close();
//
//					System.out.println("Giri�:" + rezervasyonGiris + "��k��:" + rezervasyonCikis + "Musteri:" + musteri + "Oda:" + oda);
//
//				} catch (HibernateException e) {
//					e.printStackTrace();
//				}
	
//			
//			connection = getConnection();
//			PreparedStatement psmt = connection
//					.prepareStatement("INSERT INTO  tbl_rezervasyon (CIKIS,GIRIS ) Select tbl_rezervasyon.giris,tbl_rezervasyon.cikis From tbl_musteri INNER JOIN tbl_rezervasyon ON tbl_rezervasyon.musteri_id=tbl_musteri.musteri_id");
//
//			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
//			String dateOfBirth = sdf.format(rezervasyonGiris);
//			
//			SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
//			String dateOfBirth2 = sdf2.format(rezervasyonCikis);
//		    rez.setRezervasyonGiris(rezervasyonGiris);
//			psmt.setInt(1, rezervasyonId);
//			psmt.setDate(2, sdf);
//			psmt.setDate(3,(java.sql.Date)rezervasyonGiris);
//			psmt.setInt(4, musteriId);
//			psmt.setInt(5, odaId);
			
//			
//		
			
//			psmt.setInt(3, musteri.getMusteriId());
//			psmt.setInt(4, oda.getOdaId());
//			psmt.setString(5, musteri.getMusteriAd());
//			psmt.setString(6, musteri.getMusteriSoyad());

//			result = psmt.executeUpdate();
//
//			connection.close();
//		} catch (Exception e) {
//			System.out.println(e);
//		}
	
	public String edit(int odaId) {
		Oda oda = null;

		try {
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select  oda_fiyat from tbl_oda where   oda_id=3;" + odaId);
			rs.next();
			oda = new Oda();
			oda.setOdaId(rs.getInt("ODA_ID"));

			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "/odalar.xhtml?faces-redirect=true";
	}

//	SessionFactory sessionFactory = (SessionFactory) HibernateUtil.getSessionfactory().openSession();
//	Session session = sessionFactory.getCurrentSession();
//	Transaction tx = session.beginTransaction();
//
//	public void sorgu() {
//		
//		String hql = "FROM tbl_rezervasyon";
//		Query query = session.createQuery(hql);
//		List results = query.list();
//	}
}
