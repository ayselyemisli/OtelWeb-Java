package com.ays.beans;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ays.entity.Bolum;
import com.ays.entity.Musteri;
import com.ays.entity.Personel;
import com.ays.util.DBUtil;


@ManagedBean(name = "personel")
@RequestScoped
public class PersonelBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private int personelId;
	private String personelAd;
	private String personelSoyad;
	private String password;
	private String userName;
	private String personelMail;
	Connection connection;
	ArrayList personelList;
	ArrayList personelDetayList;
	
	BolumBean bolumId;
	private Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

	public PersonelBean() {

	}

	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/oteldb?useSSL=false&amp;serverTimezone=UTC", "root", "1234");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}

	public PersonelBean(String personelAd, String personelSoyad, String password, String userName,
			String personelMail) {
		this.personelAd = personelAd;
		this.personelSoyad = personelSoyad;
		this.password = password;
		this.userName = userName;
		this.personelMail = personelMail;
	}

	public int getPersonelId() {
		return personelId;
	}

	public void setPersonelId(int personelId) {
		this.personelId = personelId;
	}

	public String getPersonelAd() {
		return personelAd;
	}

	public void setPersonelAd(String personelAd) {
		this.personelAd = personelAd;
	}

	public String getPersonelSoyad() {
		return personelSoyad;
	}

	public void setPersonelSoyad(String personelSoyad) {
		this.personelSoyad = personelSoyad;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPersonelMail() {
		return personelMail;
	}

	public void setPersonelMail(String personelMail) {
		this.personelMail = personelMail;
	}

	public ArrayList getPersonelList() {
		return personelList;
	}

	public void setPersonelList(ArrayList personelList) {
		this.personelList = personelList;
	}

	public ArrayList getPersonelDetayList() {
		return personelDetayList;
	}

	public void setPersonelDetayList(ArrayList personelDetayList) {
		this.personelDetayList = personelDetayList;
	}
	


	public BolumBean getBolumId() {
		return bolumId;
	}

	public void setBolumId(BolumBean bolumId) {
		this.bolumId = bolumId;
	}

	public String personelLogin() {
	

		Connection con = null;
		PreparedStatement ps = null;

		try {
			con = DBUtil.getMySQLConnection();
			ps = con.prepareStatement(
					"Select username, password from tbl_personel where username = ? and password = ?");
			ps.setString(1, userName);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
					return "personelislem2.xhtml?faces-redirect=true";
			}

		} catch (Exception e) {
			System.out.println("Hata" + e.getMessage());

		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		return "error.jsp?redirect=true";
	}

	// tbl_personel liste.Personeller baz� detaylar� gorebilcek
	public ArrayList personelList() {
		BolumBean bolum=new BolumBean();
		try {
			personelList = new ArrayList();
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select*from tbl_personel");
//		"select p.PASSWORD,p.PERSONEL_EMAIL,p.USERNAME,d.PERSONEL_ID,d.PERSONEL_AD,d.PERSONEL_SOYAD FROM tbl_personel_detay p INNER JOIN tbl_personel d ON p.PERSONEL_ID=d.PERSONEL_ID where d.PERSONEL_ID;");
			while (rs.next()) {
				PersonelBean personel = new PersonelBean();
				personel.setPersonelId(personelId);
				personel.setPersonelId(rs.getInt("PERSONEL_ID"));
				personel.setPersonelAd(rs.getString("PERSONEL_AD"));
				personel.setPersonelSoyad(rs.getString("PERSONEL_SOYAD"));
				personel.setPassword(rs.getString("PASSWORD"));
				personel.setUserName(rs.getString("USERNAME"));
				personel.setPersonelMail(rs.getString("PERSONEL_EMAIL"));
			//	bolum.setBolumId(rs.getInt("bolum_BOLUM_ID"));

				personelList.add(personel);
				personelList.add(bolum);
			}
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return personelList;
	}

	//Yonetici yapabilcek-SAVE

	public String save() {
		int result = 0;
		try {
			connection = getConnection();
			PreparedStatement psmt = connection.prepareStatement(
					"INSERT INTO tbl_personel(PERSONEL_AD,PERSONEL_SOYAD,PERSONEL_MAIL,PASSWORD,USERNAME)VALUES(?,?,?,?,?)");

			psmt.setString(1, personelAd);
			psmt.setString(2, personelSoyad);
			psmt.setString(3, personelMail);
			psmt.setString(4, password);
			psmt.setString(5, userName);
			result = psmt.executeUpdate();

			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		if (result != 0)
			return "personelLogin.xhtml?faces-redirect=true";
		else
			return "error.jsp?faces-redirect=true";
	}

	
	//Yonetici yapabilecek-EDIT
	public String edit(int personelId) {
		PersonelBean per = null;
		BolumBean bolum =new BolumBean();
		System.out.println(personelId);
		System.out.println();
		try {
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_personel where PERSONEL_ID= " + (personelId) );
			rs.next();
		    per = new PersonelBean();
		    per.setPersonelId(rs.getInt("PERSONEL_ID"));
		    per.setPassword(rs.getString("PASSWORD"));
		    per.setPersonelAd(rs.getString("PERSONEL_AD"));
		    per.setPersonelMail(rs.getString("PERSONEL_EMAIL"));
		    per.setPersonelSoyad(rs.getString("PERSONEL_SOYAD"));
		    per.setUserName(rs.getString("USERNAME"));
		    bolum.setBolumId(rs.getInt("bolum_BOLUM_ID"));
		   


			System.out.println(rs.getString("PASSWORD"));

			sessionMap.put("editPersonel", per);
			sessionMap.put("editBolum", bolum);
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "/editPersonel.xhtml?faces-redirect=true";
	}



	public String update(Personel personel) {
Bolum bolum=new Bolum();
		try {
			
			connection = getConnection();
			PreparedStatement psmt = connection.prepareStatement(
					"UPDATE tbl_personel set p.bolum_bolum_id=b.bolum_id from  tbl_personel p,tbl_bolum b WHERE p.bolum_bolum_id=b.bolum_id");
			
				
//						UPDATE A
//					    SET A.NAME = B.NAME
//					FROM TableNameA A, TableNameB B
//					WHERE A.ID = B.ID
//					
			//		"update tbl_personel set  PASSWORD=?,PERSONEL_AD=?,PERSONEL_EMAIL=?,PERSONEL_SOYAD=?,USERNAME=?,bolum_BOLUM_ID=? where PERSONEL_ID");
			psmt.setInt(1, personel.getPersonelId());
			psmt.setString(2, personel.getPassword());
			psmt.setString(3, personel.getPersonelAd());
			psmt.setString(4, personel.getPersonelMail());
			psmt.setString(5, personel.getPersonelSoyad());
			psmt.setString(6, personel.getUserName());
			psmt.setInt(7, bolum.getBolumId());
		
			
			
			psmt.executeUpdate();
			connection.close();
			

	

		} catch (Exception e) {
			System.out.println("HATA!," + e.getMessage());
		}
		return "createPersonel.xhtml?faces-redirect=true";

	}
//Yonetici i�lemi ---Hibernate-Ekledi
	public String personelEkle() {

		try {
			Configuration config = new Configuration().configure("config/hibernate.cfg.xml");

			SessionFactory sessionFactory = config.buildSessionFactory();

			Session session = sessionFactory.openSession();
			Transaction trx = session.beginTransaction();
			Bolum bolum = new Bolum();
			Personel personel = new Personel();
			personel.setUserName(userName);
			personel.setPassword(password);
			personel.setPersonelAd(personelAd);
			personel.setPersonelSoyad(personelSoyad);
			personel.setPersonelMail(personelMail);
			session.save(personel);

			trx.commit();
			session.close();
			System.out.println("Personel  Eklendi!");
		} catch (HibernateException e) {
			System.out.println("HATA!," + e.getMessage());
		}
		return "personelLogin.xhtml?faces-redirect=true";

	}
//Yonetici i�lemi-Delete-Siliyor
	public void delete(int personelId) {
		try {
			connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement("delete from tbl_personel where PERSONEL_ID = " + personelId);
			stmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
