package com.ays.beans;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.ays.entity.Bolum;
import com.ays.entity.Musteri;
import com.ays.entity.Personel;

@ManagedBean(name = "bolum")
@RequestScoped
public class BolumBean implements Serializable {

	private int bolumId;
	private String bolumAd;
	ArrayList bolumList;
	PersonelBean personelId, personelAd, personelSoyad, password, userName, personelMail;

	private Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

	Connection connection;

	// BO� CONSTRUCTOR
	public BolumBean() {

	}

	// GETTER SETTER

	public int getBolumId() {
		return bolumId;
	}

	public void setBolumId(int bolumId) {
		this.bolumId = bolumId;
	}

	public String getBolumAd() {
		return bolumAd;
	}

	public void setBolumAd(String bolumAd) {
		this.bolumAd = bolumAd;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public ArrayList getBolumList() {
		return bolumList;
	}

	public void setBolumList(ArrayList bolumList) {
		this.bolumList = bolumList;
	}

	public PersonelBean getPersonelAd() {
		return personelAd;
	}

	public void setPersonelAd(PersonelBean personelAd) {
		this.personelAd = personelAd;
	}

	public PersonelBean getPersonelSoyad() {
		return personelSoyad;
	}

	public void setPersonelSoyad(PersonelBean personelSoyad) {
		this.personelSoyad = personelSoyad;
	}

	public PersonelBean getPassword() {
		return password;
	}

	public void setPassword(PersonelBean password) {
		this.password = password;
	}

	public PersonelBean getUserName() {
		return userName;
	}

	public void setUserName(PersonelBean userName) {
		this.userName = userName;
	}

	public PersonelBean getPersonelMail() {
		return personelMail;
	}

	public void setPersonelMail(PersonelBean personelMail) {
		this.personelMail = personelMail;
	}

	public PersonelBean getPersonelId() {
		return personelId;
	}

	public void setPersonelId(PersonelBean personelId) {
		this.personelId = personelId;
	}

	// CONNCETION
	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/oteldb?useSSL=false&amp;serverTimezone=UTC", "root", "1234");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}

	// TUM LISTE
	public ArrayList bolumList() {
		bolumList = new ArrayList();

		try {

			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_bolum");
			while (rs.next()) {

				Bolum bol = new Bolum();
				bol.setBolumAd(rs.getString("BOLUM_AD"));
				bol.setBolumId(rs.getInt("BOLUM_ID"));
				bolumList.add(bol);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return bolumList;

	}

	// KAYDET(SAVE)
	public String save() {

		int result = 0;

		try {
			connection = getConnection();
			PreparedStatement psmt = connection
					.prepareStatement("INSERT INTO tbl_bolum (BOLUM_ID,BOLUM_AD) VALUES(?,?)");
			psmt.setInt(1, bolumId);
			psmt.setString(2, bolumAd);
			result = psmt.executeUpdate();
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();

		}
		if (result != 0)
			return "personelislem2.xhtml?faces-redirect=true";
		else
			return "personelLogin.xhtml?faces-redirect=true";
	}

	// DUZENLE(EDIT)
	public String edit(int bolumId) {
		Bolum bolum = null;
		System.out.println(bolumId);
		try {
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_bolum where BOLUM_ID = " + (bolumId));
			rs.next();
			bolum = new Bolum();
			bolum.setBolumId(rs.getInt("BOLUM_ID"));
			bolum.setBolumAd(rs.getString("BOLUM_AD"));

			sessionMap.put("editBolum", bolum);
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "/edit.xhtml?faces-redirect=true";
	}

	// sil(delete)
	public void delete(int bolumId) {
		try {
			connection = getConnection();
			PreparedStatement stmt = connection.prepareStatement("delete from tbl_bolum where BOLUM_ID = " + bolumId);
			stmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// Guncelleme(id) UPDATE
	public String update(Bolum bolum) {

		try {
			connection = getConnection();
			PreparedStatement psmt = connection.prepareStatement("update tbl_bolum set bolumAd=? where bolumId=?");
			psmt.setString(1, bolum.getBolumAd());
			psmt.setInt(2, bolum.getBolumId());
			psmt.executeUpdate();
			connection.close();
		} catch (Exception e) {
			System.out.println();
		}
		return "/personelislem2.xhtml?faces-redirect=true";
	}

}
