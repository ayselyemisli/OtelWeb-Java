package com.ays.beans;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.swing.JOptionPane;

import com.ays.entity.Musteri;
import com.ays.entity.Oda;
import com.ays.entity.Rezarvasyon;
import com.ays.util.DBUtil;

@ManagedBean
@RequestScoped
public class OdaBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private int odaId;
	private String odaFiyat;
	private String odaDetay;
	private Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

	Connection connection;

	// 1-Kriterli sorgu i�in
	ArrayList odaList, odaList2, odaList3, odaList4, odaList5, odaList6, odaLis;
	// 2-tabloda ili�ki oldu�u sorgunun sonucu istedi�im gibi
	// gelmedi.MUsteri+Oda+Rezervasyon Bilgileri
	RezarvasyonBean rezervasyonId, rezervasyonGiris, rezervasyonCikis;
	MusteriBean musteriId, musteriAd, musteriSoyad;

	// ArrayList odaAra; ==>AramaBean s�n�f�mda yapt�m.Kals�n �imdilik

	public OdaBean() {

	}

	public OdaBean(int odaId, String odaFiyat, String odaDetay) {

		this.odaId = odaId;
		this.odaFiyat = odaFiyat;
		this.odaDetay = odaDetay;
	}

	public OdaBean(ArrayList odaList) {

		this.odaList = odaList;
	}

	public ArrayList getOdaList2() {
		return odaList2;
	}

	public void setOdaList2(ArrayList odaList2) {
		this.odaList2 = odaList2;
	}

	public ArrayList getOdaList3() {
		return odaList3;
	}

	public void setOdaList3(ArrayList odaList3) {
		this.odaList3 = odaList3;
	}

	public ArrayList getOdaList4() {
		return odaList4;
	}

	public void setOdaList4(ArrayList odaList4) {
		this.odaList4 = odaList4;
	}

	public ArrayList getOdaList5() {
		return odaList5;
	}

	public void setOdaList5(ArrayList odaList5) {
		this.odaList5 = odaList5;
	}

	public ArrayList getOdaList6() {
		return odaList6;
	}

	public void setOdaList6(ArrayList odaList6) {
		this.odaList6 = odaList6;
	}

	public ArrayList getOdaLis() {
		return odaLis;
	}

	public void setOdaLis(ArrayList odaLis) {
		this.odaLis = odaLis;
	}

	public RezarvasyonBean getRezervasyonId() {
		return rezervasyonId;
	}

	public void setRezervasyonId(RezarvasyonBean rezervasyonId) {
		this.rezervasyonId = rezervasyonId;
	}

	public RezarvasyonBean getRezervasyonGiris() {
		return rezervasyonGiris;
	}

	public void setRezervasyonGiris(RezarvasyonBean rezervasyonGiris) {
		this.rezervasyonGiris = rezervasyonGiris;
	}

	public RezarvasyonBean getRezervasyonCikis() {
		return rezervasyonCikis;
	}

	public void setRezervasyonCikis(RezarvasyonBean rezervasyonCikis) {
		this.rezervasyonCikis = rezervasyonCikis;
	}

	public MusteriBean getMusteriId() {
		return musteriId;
	}

	public void setMusteriId(MusteriBean musteriId) {
		this.musteriId = musteriId;
	}

	public MusteriBean getMusteriAd() {
		return musteriAd;
	}

	public void setMusteriAd(MusteriBean musteriAd) {
		this.musteriAd = musteriAd;
	}

	public MusteriBean getMusteriSoyad() {
		return musteriSoyad;
	}

	public void setMusteriSoyad(MusteriBean musteriSoyad) {
		this.musteriSoyad = musteriSoyad;
	}

	public int getOdaId() {
		return odaId;
	}

	public void setOdaId(int odaId) {
		this.odaId = odaId;
	}
	

	public String getOdaFiyat() {
		return odaFiyat;
	}

	public void setOdaFiyat(String odaFiyat) {
		this.odaFiyat = odaFiyat;
	}

	public String getOdaDetay() {
		return odaDetay;
	}

	public void setOdaDetay(String odaDetay) {
		this.odaDetay = odaDetay;
	}

	public ArrayList getOdaList() {
		return odaList;
	}

	public void setOdaList(ArrayList odaList) {
		this.odaList = odaList;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	
	
	//CONNECTION

	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/oteldb?useSSL=false&amp;serverTimezone=UTC", "root", "1234");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}
	
	
	//ODA LISTESI=TUM

	public ArrayList odaList() {
		try {
			odaList = new ArrayList();
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_oda ");
			while (rs.next()) {
				Oda oda = new Oda();
				oda.setOdaId(rs.getInt("ODA_ID"));
				oda.setOdaDetay(rs.getString("ODA_DETAY"));
				oda.setOdaFiyat(rs.getString("ODA_FIYAT"));

				odaList.add(oda);
			}
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return odaList;
	}
	
	//ODA ID si 3 +JSF de foto�ra�la entegre

	public ArrayList odaList2() {
		try {
			odaList2 = new ArrayList();
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_oda where oda_id=3 ");
			while (rs.next()) {
				Oda oda = new Oda();
				oda.setOdaId(rs.getInt("ODA_ID"));
				oda.setOdaDetay(rs.getString("ODA_DETAY"));
				oda.setOdaFiyat(rs.getString("ODA_FIYAT"));

				odaList2.add(oda);
			}
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return odaList2;
	}
	
	//Oda id si 21  +JSF de foto�ra�la entegre

	public ArrayList odaList3() {
		try {
			odaList3 = new ArrayList();
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_oda where oda_id=21 ");
			while (rs.next()) {
				Oda oda = new Oda();
				oda.setOdaId(rs.getInt("ODA_ID"));
				oda.setOdaDetay(rs.getString("ODA_DETAY"));
				oda.setOdaFiyat(rs.getString("ODA_FIYAT"));

				odaList3.add(oda);
			}
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return odaList3;
	}

	//oda id si 6 + JSF de foto�ra�la entegre
	public ArrayList odaList4() {
		try {
			odaList4 = new ArrayList();
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_oda where oda_id=6 ");
			while (rs.next()) {
				Oda oda = new Oda();
				oda.setOdaId(rs.getInt("ODA_ID"));
				oda.setOdaDetay(rs.getString("ODA_DETAY"));
				oda.setOdaFiyat(rs.getString("ODA_FIYAT"));

				odaList4.add(oda);
			}
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return odaList4;
	}
//Oda id 9  +JSF de foto�ra�la entegre
	public ArrayList odaList5() {
		try {
			odaList5 = new ArrayList();
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_oda where oda_id=9 ");
			while (rs.next()) {
				Oda oda = new Oda();
				oda.setOdaId(rs.getInt("ODA_ID"));
				oda.setOdaDetay(rs.getString("ODA_DETAY"));
				oda.setOdaFiyat(rs.getString("ODA_FIYAT"));

				odaList5.add(oda);
			}
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return odaList5;
	}

	//oda id 12 + JSF de foto�ra�la entegre
	public ArrayList odaList6() {
		try {
			odaList6 = new ArrayList();
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_oda where oda_id=12 ");
			while (rs.next()) {
				Oda oda = new Oda();
				oda.setOdaId(rs.getInt("ODA_ID"));
				oda.setOdaDetay(rs.getString("ODA_DETAY"));
				oda.setOdaFiyat(rs.getString("ODA_FIYAT"));

				odaList6.add(oda);
			}
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return odaList6;
	}

	//KAYDET
	public String save() {
		int result = 0;
		try {
			connection = getConnection();
			PreparedStatement psmt = connection
					.prepareStatement("INSERT INTO tbl_oda (ODA_FIYAT,ODA_DETAY)VALUES(?,?)");

			psmt.setString(1, odaFiyat);
			psmt.setString(2, odaDetay);

			result = psmt.executeUpdate();

			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		if (result != 0)
			return "odadetay.xhtml?faces-redirect=true";
		else
			return "personelislem2.xhtml?faces-redirect=true";
	}

	
	//DUZENLE
	public String edit(int odaId) {
		OdaBean oda = null;
		System.out.println(odaId);
		try {
			connection = getConnection();
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from tbl_oda where ODA_ID = " + (odaId));
			rs.next();
			oda = new OdaBean();
			oda.setOdaId(rs.getInt("ODA_ID"));
			oda.setOdaDetay(rs.getString("ODA_DETAY"));
			oda.setOdaFiyat(rs.getString("ODA_FIYAT"));

			sessionMap.put("editO", oda);
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "/editOda.xhtml?faces-redirect=true";
	}
	

	//G�NCELLE
	public String update(OdaBean oda) {

		try {
			connection = getConnection();
			PreparedStatement psmt = connection
					.prepareStatement("update tbl_oda set oda_detay=?,oda_fiyat=? where oda_id=?");
			psmt.setInt(1, oda.getOdaId());
			
			psmt.setString(2, oda.getOdaDetay());
			psmt.setString(3, oda.getOdaFiyat());
			psmt.executeUpdate();
			connection.close();
		} catch (Exception e) {
			System.out.println();
		}
		return "/editOda.xhtml?faces-redirect=true";
	}
	
	
	//S�L

	public void delete(int odaId) {
		try {
			connection = getConnection();
			PreparedStatement stmt = connection.prepareStatement("delete from tbl_oda where ODA_ID = " + odaId);
			stmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
