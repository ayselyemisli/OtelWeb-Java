package com.ays.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import com.ays.dao.BolumDao;
import com.ays.dao.EtkinlikDao;
import com.ays.dao.MusteriDao;
import com.ays.dao.OdaDao;
import com.ays.dao.PersonelDao;
import com.ays.dao.RezervasyonDao;
import com.ays.dao.YoneticiDao;
import com.ays.dao.impl.BolumDaoImp;
import com.ays.dao.impl.EtkinlikDaoImp;
import com.ays.dao.impl.MusteriDaoImp;
import com.ays.dao.impl.OdaDaoImp;
import com.ays.dao.impl.PersonelDaoImp;
import com.ays.dao.impl.RezervasyonDaoImp;
import com.ays.dao.impl.YoneticiDaoImp;
import com.ays.entity.Bolum;
import com.ays.entity.EtkinlikRezervasyon;
import com.ays.entity.Musteri;
import com.ays.entity.Oda;
import com.ays.entity.Personel;
import com.ays.entity.Rezarvasyon;

public class Test {

	private static MusteriDao musteriDao = new MusteriDaoImp();
	private static EtkinlikDao etkinlikDao = new EtkinlikDaoImp();
	private static RezervasyonDao rezDao = new RezervasyonDaoImp();
	private static OdaDao odaDao = new OdaDaoImp();
	private static BolumDao bolumDao = new BolumDaoImp();
	private static PersonelDao personelDao = new PersonelDaoImp();
	private static YoneticiDao yoneticiDao = new YoneticiDaoImp();

	public static void main(String[] args) throws ParseException {

		// CREATE
		//odaRezervasyonMusteri();
		// UPDATE CFG
		//yoneticiBilgi();
		//personelBilgieri();
		//musteriEtkinlikRezervasyon();
       // etkinlikDetay();

	}

	private static void odaRezervasyonMusteri() throws ParseException {
		Oda oda = new Oda();
		oda.setOdaFiyat("2000");
		oda.setOdaDetay(
				"SUPERIOR: Ortalama 25m� b�y�kl�kteki odalarda �ift ki�ilik yatak / iki ayr� yatak se�enekleri mevcuttur. Odalar�n tamam� bah�e manzaral�d�r. Superior oda: Maksimum konaklama say�s� 2+1�dir");

		Oda oda2 = new Oda();
		oda2.setOdaFiyat("3000");
		oda2.setOdaDetay(
				"DELUXE:Ortalama 34m�, �ift ki�ilik yatak ve oturma gurubu dalar deniz manzaral�. Deluxe oda: Maksimum konaklama say�s� 2+1�dir.");

		Oda oda3 = new Oda();
		oda3.setOdaFiyat("1700");
		oda3.setOdaDetay(
				"PREMIUM:Ortalama 25m� �ift ki�ilik veya iki ayr� yatak se�enekleri bulunmaktad�r Odalar�n tamam� deniz ve/veya havuz manzaral�d�r. Premium oda: Maksimum konaklama say�s� 2+1�dir.");

		Oda oda4 = new Oda();
		oda4.setOdaFiyat("2000");
		oda4.setOdaDetay(
				"PARK SUIT:Ortalama 40m�, b�y�kl�kteki odalar, kap�yla ayr�lm�� iki yatak odas�ndan olu�maktad�r. Odalarda �ift ki�ilik yatak ve a��l�r kanepe mevcuttur. Maksimum konaklama say�s� 2+2� dir.");

		Oda oda5 = new Oda();
		oda5.setOdaFiyat("1500");
		oda5.setOdaDetay(
				"AILE ODASI:Ortalama 35m�, b�y�kl�kteki odalar, iki ayr� yatakl� oda ve kap�yla ayr�lm�� ebeveyn odas�ndan olu�maktad�r. Ebeveyn odalar�nda �ift ki�ilik veya iki ayr� yatak se�ene�i mevcuttur.");

		Oda oda6 = new Oda();
		oda6.setOdaFiyat("1300");
		oda6.setOdaDetay(
				"CLUB STATNDART: 5 adet engelli odas� dahil. Ortalama 23m� b�y�kl�kteki odalarda �ift ki�ilik yatak. iki ayr� yatak se�enekleri mevcuttur. Standart odalardaki maksimum konaklama say�s� 2+1� dir.");

		Oda oda7 = new Oda();
		oda7.setOdaFiyat("2000");
		oda7.setOdaDetay(
				"DUBLEX ODA :Ortalama 43m� b�y�kl�kteki odalar, alt katta kap�yla ayr�lm�� �ift ki�ilik yatak odas� ve �st katta iki ayr� yatakl� odadan olu�maktad�r. Dublex odalarda maksimum konaklama say�s� 4�t�r.");

		Oda oda8 = new Oda();
		oda8.setOdaFiyat("1100");
		oda8.setOdaDetay(
				"PARK STANDART: Ortalama 21m� b�y�kl�kteki odalarda �ift ki�ilik yatak / iki ayr� yatak se�enekleri mevcuttur. Standart odalardaki maksimum konaklama say�s� 2+1� dir.");

		Musteri musteri = new Musteri();
		musteri.setMusteriAd("Asl�naz");
		musteri.setMusteriSoyad("Kalender");
		musteri.setAddress("�ankaya/Ankara");
		musteri.setMusteriMail("aslinaz@gmail.com");
		musteri.setGender("Kad�n");
		musteri.setMusteriPassword("asli12345");
		musteri.setMusteriTelefon("05412097865");
		musteri.setUserName("nazasli12");

		Musteri musteri2 = new Musteri();
		musteri2.setMusteriAd("Burcu");
		musteri2.setMusteriSoyad("Y�lmaz");
		musteri2.setAddress("Ke�i�ren/Ankara");
		musteri2.setMusteriMail("burcuylmz@gmail.com");
		musteri2.setGender("Kad�n");
		musteri2.setMusteriPassword("burcu123");
		musteri2.setMusteriTelefon("05442124865");
		musteri2.setUserName("burcuburcu");

		Musteri musteri3 = new Musteri();
		musteri3.setMusteriAd("Yal�n");
		musteri3.setMusteriSoyad("Yenilmez");
		musteri3.setAddress("Be�ikta�/�stanbul");
		musteri3.setMusteriMail("yalinyenilmez78@gmail.com");
		musteri3.setGender("Erkek");
		musteri3.setMusteriPassword("yalin1234");
		musteri3.setMusteriTelefon("05352047290");
		musteri3.setUserName("ylnynlmz");

		Musteri musteri4 = new Musteri();
		musteri4.setMusteriAd("Ahmet");
		musteri4.setMusteriSoyad("�im�ek");
		musteri4.setAddress("�skenderun/Hatay");
		musteri4.setMusteriMail("ahmets1@gmail.com");
		musteri4.setGender("Erkek");
		musteri4.setMusteriPassword("ahmet7656");
		musteri4.setMusteriTelefon("05463456789");
		musteri4.setUserName("ahmet5634");

		Musteri musteri5 = new Musteri();
		musteri5.setMusteriAd("Cenk");
		musteri5.setMusteriSoyad("Torun");
		musteri5.setAddress("Nil�fer/Bursa");
		musteri5.setMusteriMail("cenk33@hotmail.com");
		musteri5.setGender("Erkek");
		musteri5.setMusteriPassword("cenkcenk1");
		musteri5.setMusteriTelefon("05423456789");
		musteri5.setUserName("cenkcnk");

		Musteri musteri6 = new Musteri();
		musteri6.setMusteriAd("K�bra");
		musteri6.setMusteriSoyad("�im�ek");
		musteri6.setAddress("Sar�yer/�stanbul");
		musteri6.setMusteriMail("kubrasimsek@gmail.com");
		musteri6.setGender("Kad�n");
		musteri6.setMusteriPassword("kubra45");
		musteri6.setMusteriTelefon("05432456789");
		musteri6.setUserName("kbrsmskk");

		Musteri musteri7 = new Musteri();
		musteri7.setMusteriAd("Aylin");
		musteri7.setMusteriSoyad("Do�ru");
		musteri7.setAddress("Tarsus/Mersin");
		musteri7.setMusteriMail("aylindogru6@gmail.com");
		musteri7.setGender("Kad�n");
		musteri7.setMusteriPassword("aylinay7");
		musteri7.setMusteriTelefon("05353678213");
		musteri7.setUserName("aylintar90");

		Musteri musteri8 = new Musteri();
		musteri8.setMusteriAd("Esma");
		musteri8.setMusteriSoyad("Y�ld�z");
		musteri8.setAddress("�ankaya/Ankara");
		musteri8.setMusteriMail("esmaaa@gmail.com");
		musteri8.setGender("Kad�n");
		musteri8.setMusteriPassword("esmayldz");
		musteri8.setMusteriTelefon("05556743434");
		musteri8.setUserName("esma9292");

		Rezarvasyon rez = new Rezarvasyon();
		rezDao.RezarvasyonBilgileri("12/07/2020", "18/07/2020",musteri, oda);

		Rezarvasyon rez2 = new Rezarvasyon();
		rezDao.RezarvasyonBilgileri("13/07/2020","22/07/2020", musteri2, oda2);

		Rezarvasyon rez3 = new Rezarvasyon();
		rezDao.RezarvasyonBilgileri("10/07/2020","16/07/2020", musteri3, oda3);

		Rezarvasyon rez4 = new Rezarvasyon();
		rezDao.RezarvasyonBilgileri("18/07/2020","27/07/2020", musteri4, oda4);
		Rezarvasyon rez5 = new Rezarvasyon();
		rezDao.RezarvasyonBilgileri("08/07/2020","16/07/2020", musteri5, oda5);

		Rezarvasyon rez6 = new Rezarvasyon();
		rezDao.RezarvasyonBilgileri("04/07/2020","09/07/2020", musteri6, oda6);

		Rezarvasyon rez7 = new Rezarvasyon();
		rezDao.RezarvasyonBilgileri("16/07/2020","21/07/2020", musteri7, oda7);

		Rezarvasyon rez8 = new Rezarvasyon();
		rezDao.RezarvasyonBilgileri("17/07/2020", "29/07/2020", musteri8, oda8);

	}

	private static void yoneticiBilgi() {
		yoneticiDao.yoneticiBilgileri("arzuistanbul12", "arzuyml", "Arzu", "Yenilmez");
		yoneticiDao.yoneticiBilgileri("sevda9812", "sevdatrk", "Sevda", "T�rk");
		yoneticiDao.yoneticiBilgileri("aysunyml99", "aysunyml48", "Aysun", "Yenilmez");

	}

	private static void personelBilgieri() {

		Bolum bolum = new Bolum();
		bolum.setBolumAd("ETKINLIK");

		Bolum bolum2 = new Bolum();
		bolum2.setBolumAd("TEMIZLIK");

		Bolum bolum3 = new Bolum();
		bolum3.setBolumAd("�AMA�IRHANE");

		Bolum bolum4 = new Bolum();
		bolum4.setBolumAd("MUTFAK");

		Bolum bolum5 = new Bolum();
		bolum5.setBolumAd("GUVENLIK");

		Bolum bolum6 = new Bolum();
		bolum6.setBolumAd("MUHASEBE");

		Bolum bolum7 = new Bolum();
		bolum7.setBolumAd("RESEPSIYON");

		Bolum bolum8 = new Bolum();
		bolum8.setBolumAd("INSAN KAYNAKLARI");

		Bolum bolum9 = new Bolum();
		bolum9.setBolumAd("SA�LIK");

		Bolum bolum10 = new Bolum();
		bolum10.setBolumAd("KAT PERSONEL");

		personelDao.personelTumBilgiler("Arzu", "�ahin", "arzshn1", "arzu9898", "arzshn@gmail.com", bolum);
		personelDao.personelTumBilgiler("Aysun", "Demir", "aysundemir12", "demirays", "aysndmr@gmail.com", bolum2);
		personelDao.personelTumBilgiler("Sevda", "Y�ld�zer", "sevda98989", "sevdayld", "sevdayldr@gmail.com", bolum3);
		personelDao.personelTumBilgiler("Sezer", "Can", "sezer968", "szr123", "sezercan@gmail.com", bolum4);
		personelDao.personelTumBilgiler("Aynur", "Canik", "aynurcank1", "138467", "aynurcank27@gmail.com", bolum5);
		personelDao.personelTumBilgiler("Furkan", "Bahar", "furkan676", "furkanbahar21", "furknbhr@gmail.com", bolum6);
		personelDao.personelTumBilgiler("Faruk", "�en", " faruk4352", "farukfaruk1", "faruk526@gmail.com", bolum7);
		personelDao.personelTumBilgiler("Ya�mur", "Y�lmaz", "yagmur2638", "yagmur454", "yagmurylmaz@gmail.com", bolum8);
		personelDao.personelTumBilgiler("Yi�it", "Kalem", "yigitkml1525", "yigit525", "yigitkalm12@gmail.com", bolum9);
		personelDao.personelTumBilgiler("Hakan", "Var", "hakan1234", "minecrafthakan", "hakanvr21@gmail.com", bolum10);

	}

	private static void musteriEtkinlikRezervasyon() {
		EtkinlikRezervasyon etkinlikRezervasyon = new EtkinlikRezervasyon();
		etkinlikRezervasyon.setEtkinlikAd("KONSER");
		etkinlikRezervasyon.setEtkinlikSaat("19:00");
		etkinlikRezervasyon.setEtkinlikYer("SALONA");

		EtkinlikRezervasyon etkinlikRezervasyon2 = new EtkinlikRezervasyon();
		etkinlikRezervasyon2.setEtkinlikAd("KONSER");
		etkinlikRezervasyon2.setEtkinlikSaat("14:00");
		etkinlikRezervasyon2.setEtkinlikYer("A�IK ALAN 12C");

		EtkinlikRezervasyon etkinlikRezervasyon3 = new EtkinlikRezervasyon();
		etkinlikRezervasyon3.setEtkinlikAd("PARTI");
		etkinlikRezervasyon3.setEtkinlikSaat("00:00-05:00 ");
		etkinlikRezervasyon3.setEtkinlikYer("CLUB A");

		EtkinlikRezervasyon etkinlikRezervasyon4 = new EtkinlikRezervasyon();
		etkinlikRezervasyon4.setEtkinlikAd("PARTI");
		etkinlikRezervasyon4.setEtkinlikSaat("00:00-05:00");
		etkinlikRezervasyon4.setEtkinlikYer("CLUB B");

		EtkinlikRezervasyon etkinlikRezervasyon5 = new EtkinlikRezervasyon();
		etkinlikRezervasyon5.setEtkinlikAd("GEZI");
		etkinlikRezervasyon5.setEtkinlikSaat("08:00-18:00");
		etkinlikRezervasyon5.setEtkinlikYer("KEMER");

		EtkinlikRezervasyon etkinlikRezervasyon6 = new EtkinlikRezervasyon();
		etkinlikRezervasyon6.setEtkinlikAd("GEZI");
		etkinlikRezervasyon6.setEtkinlikSaat("08:00-18:00");
		etkinlikRezervasyon6.setEtkinlikYer("ALANYA");

		EtkinlikRezervasyon etkinlikRezervasyon7 = new EtkinlikRezervasyon();
		etkinlikRezervasyon7.setEtkinlikAd("TIYATRO");
		etkinlikRezervasyon7.setEtkinlikSaat("12:00");
		etkinlikRezervasyon7.setEtkinlikYer("ART-2");

		EtkinlikRezervasyon etkinlikRezervasyon8 = new EtkinlikRezervasyon();
		etkinlikRezervasyon8.setEtkinlikAd("TIYATRO");
		etkinlikRezervasyon8.setEtkinlikSaat("16:00");
		etkinlikRezervasyon8.setEtkinlikYer("ART-1");

		Collection<EtkinlikRezervasyon> etkinlikList = new ArrayList<EtkinlikRezervasyon>();
		etkinlikList.add(etkinlikRezervasyon);

		Collection<EtkinlikRezervasyon> etkinlikList2 = new ArrayList<EtkinlikRezervasyon>();
		etkinlikList2.add(etkinlikRezervasyon2);
		Collection<EtkinlikRezervasyon> etkinlikList3 = new ArrayList<EtkinlikRezervasyon>();
		etkinlikList3.add(etkinlikRezervasyon3);
		Collection<EtkinlikRezervasyon> etkinlikList4 = new ArrayList<EtkinlikRezervasyon>();
		etkinlikList4.add(etkinlikRezervasyon4);
		Collection<EtkinlikRezervasyon> etkinlikList5 = new ArrayList<EtkinlikRezervasyon>();
		etkinlikList5.add(etkinlikRezervasyon5);
		Collection<EtkinlikRezervasyon> etkinlikList6 = new ArrayList<EtkinlikRezervasyon>();
		etkinlikList6.add(etkinlikRezervasyon6);
		Collection<EtkinlikRezervasyon> etkinlikList7 = new ArrayList<EtkinlikRezervasyon>();
		etkinlikList7.add(etkinlikRezervasyon7);
		Collection<EtkinlikRezervasyon> etkinlikList8 = new ArrayList<EtkinlikRezervasyon>();
		etkinlikList8.add(etkinlikRezervasyon8);

		musteriDao.musteriBilgileriRezervasyonWith("Asl� Nur ", "�ahin", "Kad�n", "05464912534", "aslishn@gmail.com",
				"asli1234321", "asli1", "ANKARA", etkinlikList);
		musteriDao.musteriBilgileriRezervasyonWith("Irmak", "G�nd�z", "Kad�n", "05412345463", "irmak@gmail.com",
				"irmak1", "irmak2", "ANKARA", etkinlikList2);
		musteriDao.musteriBilgileriRezervasyonWith("Buket", "Ye�ilova", "Kad�n", "05342876543", "buket06@gmail.com",
				"buket35", "buket3", "BURSA", etkinlikList3);
		musteriDao.musteriBilgileriRezervasyonWith("Can", "Y�ld�r�m", "Erkek", "05336473889", "can78@gmail.com",
				"can1234", "can4", "ANTALYA", etkinlikList4);
		musteriDao.musteriBilgileriRezervasyonWith("Elif", "Y�lmaz", "Kad�n", "05543215467", "elify6@gmail.com",
				"elif4875", "elif5", "MU�LA", etkinlikList5);
		musteriDao.musteriBilgileriRezervasyonWith("Ozan", "Erguvan", "Erkek", "05557432134", "ozan847@gmail.com",
				"ozannergvn", "ozan6", "MERS�N", etkinlikList6);
		musteriDao.musteriBilgileriRezervasyonWith("Mehmet", "Sev", "Erkek", "05554765432", "mehmetsev1@gmail.com",
				"mehmet4475", "mehmet7", "�STANBUL", etkinlikList7);
		musteriDao.musteriBilgileriRezervasyonWith("Ali", "Erdem", "Erkek", "05454321234", "alierdem6789@gmail.com",
				"ali4789", "ali8", "YALOVA", etkinlikList8);

	}
//
//	private static void bolumEkle() {
//		bolumDao.bolumEkle("ETKINLIK");
//		bolumDao.bolumEkle("TEMIZLIK");
//		bolumDao.bolumEkle("�AMA�IRHANE");
//		bolumDao.bolumEkle("MUTFAK");
//		bolumDao.bolumEkle("GUVENLIK");
//		bolumDao.bolumEkle("MUHASEBE");
//		bolumDao.bolumEkle("RESEPSIYON");
//		bolumDao.bolumEkle("INSAN KAYNAKLARI");
//		bolumDao.bolumEkle("SA�LIK");
//		bolumDao.bolumEkle("KAT PERSONEL");
//	}

	private static void etkinlikDetay() {
		etkinlikDao.etkinlikDetay("KONSER", "SALON A", "19:00-02:00 Herg�n");
		etkinlikDao.etkinlikDetay("KONSER", "A�IK ALAN 12C", "14:00-20:00");
		etkinlikDao.etkinlikDetay("PARTI", "CLUB-A", "00:00-05:00 ALKOL VAR");
		etkinlikDao.etkinlikDetay("PARTI", "CLUB-B", "00:00-05:00 ALKOL YOK");
		etkinlikDao.etkinlikDetay("GEZI", "KEMER", "08:00-18:00");
		etkinlikDao.etkinlikDetay("GEZI", "ALANYA", "08:00-18:00");
		etkinlikDao.etkinlikDetay("TIYATRO", "ART-1", "12:00-14:40");
		etkinlikDao.etkinlikDetay("TIYATRO", "ART-2", "16:00-18:00");
		etkinlikDao.etkinlikDetay("GEZI", "YAT-1 KOY GEZ�S�", "09:00-15:00 ");
		etkinlikDao.etkinlikDetay("GEZI", "YAT-2 KOY GEZISI", "09:00-19:00");
	}
}
