package com.ays.entity;

import java.io.Serializable;

import javax.persistence.Column;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "tbl_musteri", catalog = "oteldb")
public class Musteri implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "MUSTERI_ID")
	private int musteriId;

	@Column(name = "MUSTERI_AD")
	private String musteriAd;

	@Column(name = "MUSTERI_SOYAD")
	private String musteriSoyad;

	@Column(name = "MUSTERI_TELEFON")
	private String musteriTelefon;

	@Column(name = "MUSTERI_EMAIL")
	private String musteriMail;

	@Column(name = "PASSWORD")
	private String musteriPassword;

	@Column(name = "USERNAME")
	private String userName;

	@Column(name = "ADDRESS")
	private String address;

	@Column(name = "CINSIYET")
	private String gender;

	public Musteri() {

	}
	

	public Musteri(String musteriAd, String musteriSoyad, String musteriTelefon, String musteriMail,
			String musteriPassword, String userName, String address, String gender) {

		this.musteriAd = musteriAd;
		this.musteriSoyad = musteriSoyad;
		this.musteriTelefon = musteriTelefon;
		this.musteriMail = musteriMail;
		this.musteriPassword = musteriPassword;
		this.userName = userName;
		this.address = address;
		this.gender = gender;
	}

	public  int getMusteriId() {
		return musteriId;
	}

	public void setMusteriId(int musteriId) {
		this.musteriId = musteriId;
	}

	public String getMusteriAd() {
		return musteriAd;
	}

	public void setMusteriAd(String musteriAd) {
		this.musteriAd = musteriAd;
	}

	public String getMusteriSoyad() {
		return musteriSoyad;
	}

	public void setMusteriSoyad(String musteriSoyad) {
		this.musteriSoyad = musteriSoyad;
	}

	public String getMusteriTelefon() {
		return musteriTelefon;
	}

	public void setMusteriTelefon(String musteriTelefon) {
		this.musteriTelefon = musteriTelefon;
	}

	public String getMusteriMail() {
		return musteriMail;
	}

	public void setMusteriMail(String musteriMail) {
		this.musteriMail = musteriMail;
	}

	public String getMusteriPassword() {
		return musteriPassword;
	}

	public void setMusteriPassword(String musteriPassword) {
		this.musteriPassword = musteriPassword;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


	
	
	
	

	


}
