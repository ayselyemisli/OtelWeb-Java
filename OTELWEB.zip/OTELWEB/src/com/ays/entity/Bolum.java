package com.ays.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_bolum", catalog = "oteldb")
public class Bolum implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BOLUM_ID")
	private int bolumId;

	@Column(name = "BOLUM_AD")
	private String bolumAd;

	
	public Bolum() {

	}

	@Override
	public String toString() {

		return "Bolum Id:" + bolumId + "Bolum Ad:" + bolumAd + "Personel" ;

	}

	public Bolum(String bolumAd) {

		this.bolumAd = bolumAd;

	}

	public int getBolumId() {
		return bolumId;
	}

	public void setBolumId(int bolumId) {
		this.bolumId = bolumId;
	}

	public String getBolumAd() {
		return bolumAd;
	}

	public void setBolumAd(String bolumAd) {
		this.bolumAd = bolumAd;
	}
	
	

	
	

}
