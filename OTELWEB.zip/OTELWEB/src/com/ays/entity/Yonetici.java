package com.ays.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_yonetici", catalog = "oteldb")
public class Yonetici implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "YONETICI_ID")
	private Integer yoneticiId;

	@Column(name = "PASSWORD")
	private String password;

	@Column(name = "USERNAME")
	private String userName;

	@Column(name = "YONETICI_AD")
	private String yoneticiAd;

	@Column(name = "YONETICI_SOYAD")
	private String yoneticiSoyad;

	public Yonetici() {

	}

	public Yonetici(String password, String userName, String yoneticiAd, String yoneticiSoyad) {

		this.password = password;
		this.userName = userName;
		this.yoneticiAd = yoneticiAd;
		this.yoneticiSoyad = yoneticiSoyad;

	}

	@Override
	public String toString() {

		return "AD:" + yoneticiAd + "SOYAD" + yoneticiSoyad + "PAROLA:" + password + " USERNAME" + userName;
	}

	public Integer getYoneticiId() {
		return yoneticiId;
	}

	public void setYoneticiId(Integer yoneticiId) {
		this.yoneticiId = yoneticiId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getYoneticiAd() {
		return yoneticiAd;
	}

	public void setYoneticiAd(String yoneticiAd) {
		this.yoneticiAd = yoneticiAd;
	}

	public String getYoneticiSoyad() {
		return yoneticiSoyad;
	}

	public void setYoneticiSoyad(String yoneticiSoyad) {
		this.yoneticiSoyad = yoneticiSoyad;
	}

}
