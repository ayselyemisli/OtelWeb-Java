package com.ays.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "tbl_oda", catalog = "oteldb")
public class Oda implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ODA_ID")
	private int odaId;

	@Column(name = "ODA_FIYAT")
	private String odaFiyat;

	@Column(name = "ODA_DETAY")
	private String odaDetay;

	public Oda() {

	}

	public Oda(String odaFiyat, String odaDetay) {

		this.odaFiyat = odaFiyat;
		this.odaDetay = odaDetay;

	}

	public int getOdaId() {
		return odaId;
	}

	public void setOdaId(int odaId) {
		this.odaId = odaId;
	}

	public String getOdaFiyat() {
		return odaFiyat;
	}

	public void setOdaFiyat(String odaFiyat) {
		this.odaFiyat = odaFiyat;
	}

	public String getOdaDetay() {
		return odaDetay;
	}

	public void setOdaDetay(String odaDetay) {
		this.odaDetay = odaDetay;
	}

}
