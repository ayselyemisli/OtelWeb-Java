package com.ays.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "tbl_etkinlik", catalog = "oteldb")
public class EtkinlikRezervasyon implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ETKINLIK_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int etkinlikId;

	@Column(name = "ETKINLIK_AD")
	private String etkinlikAd;

	@Column(name = "ETKINLIK_YER")
	private String etkinlikYer;

	@Column(name = "ETKINLIK_TARIH")
	private String etkinlikSaat;

	public EtkinlikRezervasyon() {

	}

	public EtkinlikRezervasyon(String etkinlikAd, String etkinlikYer, String etkinlikSaat) {

		this.etkinlikAd = etkinlikAd;
		this.etkinlikYer = etkinlikYer;
		this.etkinlikSaat = etkinlikSaat;
	}

	public int getEtkinlikId() {
		return etkinlikId;
	}

	public void setEtkinlikId(int etkinlikId) {
		this.etkinlikId = etkinlikId;
	}

	public String getEtkinlikAd() {
		return etkinlikAd;
	}

	public void setEtkinlikAd(String etkinlikAd) {
		this.etkinlikAd = etkinlikAd;
	}

	public String getEtkinlikYer() {
		return etkinlikYer;
	}

	public void setEtkinlikYer(String etkinlikYer) {
		this.etkinlikYer = etkinlikYer;
	}

	public String getEtkinlikSaat() {
		return etkinlikSaat;
	}

	public void setEtkinlikSaat(String etkinlikSaat) {
		this.etkinlikSaat = etkinlikSaat;
	}

}
