package com.ays.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SecondaryTable;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_rezervasyon", catalog = "oteldb")
@SecondaryTable(name="oda_durum")
public class Rezarvasyon implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "REZERVASYON_ID")
	private int rezervasyonId;

	@Column(name = "GIRIS")
	private Date rezervasyonGiris;

	@Column(name = "CIKIS")
	private Date rezervasyonCikis;
	

	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "MUSTERI_ID")
	private Musteri musteri;

	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ODA_ID")
	private Oda oda;
	

	public Rezarvasyon() {

	}

	public Rezarvasyon(Date rezervasyonGiris, Date rezervasyonCikis, Musteri musteri, Oda oda,int rezervasyonId) {
		this.rezervasyonId=rezervasyonId;
		this.rezervasyonGiris = rezervasyonGiris;
		this.rezervasyonCikis = rezervasyonCikis;
		this.musteri = musteri;
		this.oda = oda;
	}

	@Override
	public String toString() {

		return "REZERVASYON ID:" + rezervasyonId + "Giri�:" + rezervasyonGiris + "��k��:" + rezervasyonCikis
				+ "Musteri:" + musteri + "Oda:" + oda ;

	}
	
	

	public int getRezervasyonId() {
		return rezervasyonId;
	}

	public void setRezervasyonId(int rezervasyonId) {
		this.rezervasyonId = rezervasyonId;
	}

	
	public Date getRezervasyonGiris() {
		return rezervasyonGiris;
	}

	public void setRezervasyonGiris(Date rezervasyonGiris) {
		this.rezervasyonGiris = rezervasyonGiris;
	}

	public Date getRezervasyonCikis() {
		return rezervasyonCikis;
	}

	public void setRezervasyonCikis(Date rezervasyonCikis) {
		this.rezervasyonCikis = rezervasyonCikis;
	}

	public Musteri getMusteri() {
		return musteri;
	}

	public void setMusteri(Musteri musteri) {
		this.musteri = musteri;
	}

	public Oda getOda() {
		return oda;
	}

	public void setOda(Oda oda) {
		this.oda = oda;
	}

	public void setRezervasyonId(Oda odaId) {
		// TODO Auto-generated method stub
		
	}

	
	



	

}
