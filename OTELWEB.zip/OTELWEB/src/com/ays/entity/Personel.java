package com.ays.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SecondaryTable;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "tbl_personel", catalog = "oteldb")

public class Personel implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PERSONEL_ID")
	private int personelId;

	@Column(name = "PERSONEL_AD")
	private String personelAd;

	@Column(name = "PERSONEL_SOYAD")
	private String personelSoyad;

	@Column(name = "PASSWORD")
	private String password;

	@Column(name = "USERNAME")
	private String userName;


	@Column(name = "PERSONEL_EMAIL")
	private String personelMail;
	
	@ManyToOne(cascade = CascadeType.ALL)
	private Bolum bolum;
	



	

	public Personel() {

	}
	
	


	public Personel(String personelAd, String personelSoyad, String password, String userName, String personelMail,
		Bolum bolum) {
	
		this.personelAd = personelAd;
		this.personelSoyad = personelSoyad;
		this.password = password;
		this.userName = userName;
		this.personelMail = personelMail;
		this.bolum=bolum;
	
	}




	public int getPersonelId() {
		return personelId;
	}


	public void setPersonelId(int personelId) {
		this.personelId = personelId;
	}


	public String getPersonelAd() {
		return personelAd;
	}


	public void setPersonelAd(String personelAd) {
		this.personelAd = personelAd;
	}


	public String getPersonelSoyad() {
		return personelSoyad;
	}


	public void setPersonelSoyad(String personelSoyad) {
		this.personelSoyad = personelSoyad;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPersonelMail() {
		return personelMail;
	}


	public void setPersonelMail(String personelMail) {
		this.personelMail = personelMail;
	}




	public Bolum getBolum() {
		return bolum;
	}




	public void setBolum(Bolum bolum) {
		this.bolum = bolum;
	}

 

}
	
	



	


	


	

	
	

