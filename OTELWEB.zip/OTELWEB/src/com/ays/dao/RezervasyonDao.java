package com.ays.dao;


import java.text.ParseException;
import java.util.Date;
import java.util.List;

import com.ays.entity.Musteri;
import com.ays.entity.Oda;
import com.ays.entity.Rezarvasyon;

public interface RezervasyonDao {

	public void  RezarvasyonBilgileri( String  rezervasyonGiris, String rezervasyonCikis, Musteri musteri, Oda oda) throws ParseException;


	

	
	




}
