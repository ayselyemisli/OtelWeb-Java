package com.ays.dao;

import java.util.List;

import com.ays.entity.Musteri;
import com.ays.entity.Oda;
import com.ays.entity.Rezarvasyon;

public interface OdaDao {

	public void  OdaRezervasyon(String odaFiyat, String odaDetay);
}
