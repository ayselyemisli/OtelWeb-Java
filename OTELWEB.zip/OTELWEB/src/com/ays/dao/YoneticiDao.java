package com.ays.dao;

public interface YoneticiDao {
	
	public void yoneticiBilgileri(String password, String userName, String yoneticiAd, String yoneticiSoyad);

}
