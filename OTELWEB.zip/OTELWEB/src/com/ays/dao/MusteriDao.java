package com.ays.dao;

import java.text.ParseException;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.ays.entity.EtkinlikRezervasyon;
import com.ays.entity.Musteri;
import com.ays.entity.Oda;
import com.ays.entity.Rezarvasyon;

public interface MusteriDao {
	
	public void musteriBilgileri(String musteriAd, String musteriSoyad, String gender,String musteriTelefon, String musteriMail, String musteriPassword, String userName, String address);
	
	public void musteriBilgileriRezervasyonWith(String musteriAd, String musteriSoyad, String gender,String musteriTelefon, String musteriMail, String musteriPassword, String userName, String address, Collection<EtkinlikRezervasyon> etkinlikList);
	
	public void musteriRezervasyon(String musteriAd, String musteriSoyad);
}
