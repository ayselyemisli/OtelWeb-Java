package com.ays.dao;

import java.util.List;

import com.ays.entity.Bolum;
import com.ays.entity.Personel;

public interface PersonelDao {

	public void personeleAitBilgiler(String personelAd, String personelSoyad);

	public void personelDetayBilgiler(String password, String userName, String personelMail);
	
	public void personelTumBilgiler(String password, String userName, String personelMail,String personelAd, String personelSoyad,Bolum bolum);
	
	
}
