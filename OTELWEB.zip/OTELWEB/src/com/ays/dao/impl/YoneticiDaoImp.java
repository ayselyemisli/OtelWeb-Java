package com.ays.dao.impl;

import org.hibernate.Session;

import com.ays.dao.YoneticiDao;
import com.ays.entity.Yonetici;
import com.ays.util.HibernateUtil;

public class YoneticiDaoImp implements YoneticiDao {

	@Override
	public void yoneticiBilgileri(String password, String userName, String yoneticiAd, String yoneticiSoyad) {
		
		try {
			Session session = HibernateUtil.getSessionfactory().openSession();
			session.beginTransaction();
			Yonetici yonetici = new Yonetici();
			yonetici.setYoneticiAd(yoneticiAd);
			yonetici.setYoneticiSoyad(yoneticiSoyad);
			yonetici.setUserName(userName);
			yonetici.setPassword(password);
			
			session.save(yonetici);
			session.getTransaction().commit();
			session.clear();
			System.out.println("AD:" + yoneticiAd + "SOYAD:" + yoneticiSoyad +  "Parola:" + password + "Kullan�c� Ad�: "+ userName );
			
			}catch (Exception e) {
				e.printStackTrace();
			}
			
		
		
		
		
	}

}
