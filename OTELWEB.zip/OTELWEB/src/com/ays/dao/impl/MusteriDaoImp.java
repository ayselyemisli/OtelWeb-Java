package com.ays.dao.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;

import com.ays.dao.MusteriDao;

import com.ays.entity.EtkinlikRezervasyon;
import com.ays.entity.Musteri;
import com.ays.entity.Oda;
import com.ays.entity.Rezarvasyon;
import com.ays.util.HibernateUtil;

public class MusteriDaoImp implements MusteriDao {

	
	@Override
	public void musteriRezervasyon(String musteriAd, String musteriSoyad) {
		try {
		Session session = HibernateUtil.getSessionfactory().openSession();
		session.beginTransaction();
		Musteri musteri=new Musteri();
		musteri.setMusteriAd(musteriAd);
		musteri.setMusteriSoyad(musteriSoyad);
		
		session.save(musteri);
		
		session.getTransaction().commit();
		session.clear();
		System.out.println("AD:" + musteriAd + "SOYAD:" + musteriSoyad );
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	@Override
	public void musteriBilgileri(String musteriAd, String musteriSoyad, String gender, String musteriTelefon,
			String musteriMail, String musteriPassword, String userName, String address) {
		
		try {
			Session session = HibernateUtil.getSessionfactory().openSession();
			session.beginTransaction();
			Musteri musteri = new Musteri();
			musteri.setMusteriAd(musteriAd);
			musteri.setMusteriSoyad(musteriSoyad);
			musteri.setGender(gender);
			musteri.setMusteriTelefon(musteriTelefon);
			musteri.setMusteriMail(musteriMail);
			musteri.setMusteriPassword(musteriPassword);
			musteri.setUserName(userName);
			musteri.setAddress(address);
			session.save(musteri);
			session.getTransaction().commit();
			session.clear();
			System.out.println("AD:" + musteriAd + "SOYAD:" + musteriSoyad + "C�NS�YET" + gender +"TEL:" +
			musteriTelefon + "Mail:" + musteriMail + "Parola:" + musteriPassword + "Kullan�c� Ad�: "+ userName +
			"Adres:" + address);
			
			}catch (Exception e) {
				e.printStackTrace();
			}
			
		
		
	}



			
		
		
	


	@Override
	public void musteriBilgileriRezervasyonWith(String musteriAd, String musteriSoyad, String gender,
			String musteriTelefon, String musteriMail, String musteriPassword, String userName, String address,
			Collection<EtkinlikRezervasyon> etkinlikList) {

		try {
			Session session = HibernateUtil.getSessionfactory().openSession();
			session.beginTransaction();
			Musteri musteri = new Musteri();
			musteri.setMusteriAd(musteriAd);
			musteri.setMusteriSoyad(musteriSoyad);
			musteri.setGender(gender);
			musteri.setMusteriTelefon(musteriTelefon);
			musteri.setMusteriMail(musteriMail);
			musteri.setMusteriPassword(musteriPassword);
			musteri.setUserName(userName);
			musteri.setAddress(address);
			
			session.save(musteri);
			session.getTransaction().commit();
			session.clear();
			System.out.println("AD:" + musteriAd + "SOYAD:" + musteriSoyad + "C�NS�YET" + gender +"TEL:" +
			musteriTelefon + "Mail:" + musteriMail + "Parola:" + musteriPassword + "Kullan�c� Ad�: "+ userName +
			"Adres:" + address );
			
			}catch (Exception e) {
				e.printStackTrace();
			}
			
		
	}}


	
		
	


