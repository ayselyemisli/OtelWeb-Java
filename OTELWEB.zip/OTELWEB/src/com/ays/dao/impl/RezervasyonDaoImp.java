package com.ays.dao.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.ays.dao.RezervasyonDao;
import com.ays.entity.Musteri;
import com.ays.entity.Oda;
import com.ays.entity.Rezarvasyon;
import com.ays.util.HibernateUtil;

public class RezervasyonDaoImp implements RezervasyonDao {



	@Override
	public void RezarvasyonBilgileri(String rezervasyonGiris, String rezervasyonCikis, Musteri musteri, Oda oda) throws ParseException {
		
		try {
			Session session = HibernateUtil.getSessionfactory().openSession();
			session.beginTransaction();
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dateOfBirth = sdf.parse(rezervasyonGiris);
			
			SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
			Date dateOfBirth2 = sdf2.parse(rezervasyonCikis);
		

			Rezarvasyon rezer = new Rezarvasyon();
			rezer.setRezervasyonGiris(dateOfBirth);
			rezer.setRezervasyonCikis(dateOfBirth2);
			rezer.setMusteri(musteri);
			rezer.setOda(oda);
			

			session.save(rezer);
			session.getTransaction().commit();
			session.clear();
			session.close();

			System.out.println("Giri�:" + rezervasyonGiris + "��k��:" + rezervasyonCikis + "Musteri:" + musteri + "Oda:" + oda);

		} catch (HibernateException e) {
			e.printStackTrace();
		}

	}

	
	

}
