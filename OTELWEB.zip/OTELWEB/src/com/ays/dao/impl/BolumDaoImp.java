package com.ays.dao.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;

import com.ays.dao.BolumDao;
import com.ays.entity.Bolum;
import com.ays.entity.Personel;
import com.ays.util.HibernateUtil;

public class BolumDaoImp implements BolumDao {

	@Override
	public void bolumEkle(String bolumAd) {

		Session session = HibernateUtil.getSessionfactory().openSession();
		session.beginTransaction();
		Bolum bolum = new Bolum();
		bolum.setBolumAd(bolumAd);
		
		session.save(bolum);
		session.getTransaction().commit();
		session.clear();

		System.out.println("Bolum Ad:" + bolumAd  );
	}

}
