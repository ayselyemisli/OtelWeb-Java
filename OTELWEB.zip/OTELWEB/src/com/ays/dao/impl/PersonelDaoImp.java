package com.ays.dao.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.tomcat.util.net.jsse.PEMFile;
import org.hibernate.Session;

import com.ays.dao.PersonelDao;

import com.ays.entity.Bolum;
import com.ays.entity.Personel;
import com.ays.util.HibernateUtil;

public class PersonelDaoImp implements PersonelDao {

	

	@Override
	public void personeleAitBilgiler(String personelAd, String personelSoyad) {
		try {
			Session session = HibernateUtil.getSessionfactory().openSession();
			session.beginTransaction();
			Personel personel =new Personel();
			personel.setPersonelAd(personelAd);
			personel.setPersonelSoyad(personelSoyad);
			session.save(personel);
			session.getTransaction().commit();
			session.clear();
			
			System.out.println("AD:"+ personelAd + "SOYAD:" + personelSoyad );
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void personelDetayBilgiler(String password, String userName, String personelMail) {
		try {
			Session session = HibernateUtil.getSessionfactory().openSession();
			session.beginTransaction();
			Personel personel =new Personel();
			personel.setPassword(password);
			personel.setUserName(userName);
			personel.setPersonelMail(personelMail);
			session.save(personel);
			session.getTransaction().commit();
			session.clear();
			
			System.out.println("PAROLA:" + password + "Kullan�c� ad�:" + userName + "Mail:" + personelMail);
		
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void personelTumBilgiler( String personelAd,
			String personelSoyad,String password, String userName, String personelMail,Bolum bolum) {
		
		try {
			Session session = HibernateUtil.getSessionfactory().openSession();
			session.beginTransaction();
			Personel personel =new Personel();
			personel.setPersonelAd(personelAd);
			personel.setPersonelSoyad(personelSoyad);
			personel.setPassword(password);
			personel.setUserName(userName);
			personel.setPersonelMail(personelMail);
			personel.setBolum(bolum);
			
			
			session.save(personel);
			session.getTransaction().commit();
			session.clear();
			
			System.out.println("PAROLA:" + password + "Kullan�c� ad�:" + userName + "Mail:" + personelMail + "Ad:" + personelAd +
					"Soyad:" + personelSoyad );
		
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}
}
