package com.ays.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;

import com.ays.dao.EtkinlikDao;
import com.ays.entity.EtkinlikRezervasyon;
import com.ays.entity.Musteri;
import com.ays.util.HibernateUtil;



public class EtkinlikDaoImp implements EtkinlikDao {

	@Override
	public void etkinlikDetay(String etkinlikAd, String etkinlikYer, String etkinlikSaat) {
		Session session =HibernateUtil.getSessionfactory().openSession();
		session.beginTransaction();
		EtkinlikRezervasyon etkinlik = new EtkinlikRezervasyon(etkinlikAd,etkinlikYer,etkinlikSaat);
		session.save(etkinlik);
		session.getTransaction().commit();
		session.clear();
		
		
	}





	
}
