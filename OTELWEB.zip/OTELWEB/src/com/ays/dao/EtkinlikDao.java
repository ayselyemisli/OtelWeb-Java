package com.ays.dao;

import java.util.List;

import com.ays.entity.EtkinlikRezervasyon;
import com.ays.entity.Musteri;

public interface EtkinlikDao {
	
	public void etkinlikDetay(String etkinlikAd, String etkinlikYer, String etkinlikSaat);


}
