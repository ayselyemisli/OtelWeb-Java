package com.ays.dao;

import java.util.List;

import com.ays.entity.Bolum;
import com.ays.entity.Personel;


public interface BolumDao {

	public void bolumEkle(String bolumAd);

	

}
